from __future__ import division
from __future__ import print_function
import math
import numpy as np
import csv
import scipy.misc
import pickle
import pandas as pd
from sklearn import metrics
import gc
from collections import defaultdict

modelpath='/data/fzohora/dilution_series_syn_pep/LC_MS/'
datapath='/data/fzohora/dilution_series_syn_pep/'      #'/data/fzohora/water/' #'/media/anne/Study/study/PhD/bsi/update/data/water/'  #
dataname=['130124_dilA_10_01','130124_dilA_10_02', '130124_dilA_10_03', '130124_dilA_10_04', '130124_dilA_11_01', '130124_dilA_11_02', '130124_dilA_11_03', '130124_dilA_11_04', '130124_dilA_12_01', '130124_dilA_12_02', '130124_dilA_12_03', '130124_dilA_12_04'] 

RT_window=15
mz_window=11 #2031
total_frames_hor=6
RT_unit=0.01
mz_unit=0.01
mz_resolution=2


isotope_gap=np.zeros((10))
isotope_gap[0]=0.001
isotope_gap[1]=1.00
isotope_gap[2]=.50
isotope_gap[3]=.33
isotope_gap[4]=.25
isotope_gap[5]=.20
isotope_gap[6]=.17
isotope_gap[7]=.14
isotope_gap[8]=.13
isotope_gap[9]=.11


for data_index in range(5, len(dataname)):
    print(dataname[data_index])            
    f=open(modelpath+dataname[data_index]+'_consecutive_scan_MS1_1', 'rb') 
    ms1=pickle.load(f)
    f.close()
    f=open(modelpath+dataname[data_index]+'_consecutive_scan_MS1_2', 'rb') 
    ms1_next=pickle.load(f)
    f.close()    
    ms1=np.concatenate((ms1, np.copy(ms1_next)), axis=1)
    temp_ms1=np.zeros((ms1.shape[0]+RT_window, ms1.shape[1]+mz_window))
    temp_ms1[0:ms1.shape[0], 0:ms1.shape[1]]=np.copy(ms1[:, :])
    ms1=np.copy(temp_ms1)
    temp_ms1=0
    print('data restore done')
    f=open(datapath+'feature_list/'+dataname[data_index]+'_ms1_record', 'rb')
    RT_mz_I_dict, maxI=pickle.load(f)
    f.close()   

    print('ms1 record load done')
    f=open(datapath+'feature_list/'+dataname[data_index]+'_combineIsotopes_info', 'rb')
    total_feature,  maxI=pickle.load(f)
    f.close() 
    
    f=open(datapath+'feature_list/'+dataname[data_index]+'_combineIsotopes_auc_info', 'rb')
    RT_info=pickle.load(f)
    f.close()     
    
    RT_list = np.sort(list(RT_mz_I_dict.keys()))
    max_RT=RT_list[len(RT_list)-1]
    min_RT=10.0

    RT_index=dict()
    sorted_mz_list=[]
    for i in range(0, RT_list.shape[0]):
        RT_index[round(RT_list[i], 2)]=i
        sorted_mz_list.append(sorted(RT_mz_I_dict[RT_list[i]]))
    
    max_mz=0
    min_mz=1000
    for i in range(0, RT_list.shape[0]):
        mz_I_list=sorted_mz_list[i]
        mz=mz_I_list[len(mz_I_list)-1][0]
        if mz>max_mz:
            max_mz=mz
        mz=mz_I_list[0][0]
        if mz<min_mz:
            min_mz=mz

    rt_search_index=0
    while(RT_list[rt_search_index]<=min_RT):
        if RT_list[rt_search_index]==min_RT:
            break
        rt_search_index=rt_search_index+1 


    logfile=open(datapath+'feature_list/'+dataname[data_index]+'_combineIsotopes_featureList.csv', 'rb')
    peptide_feature=np.loadtxt(logfile, delimiter=',')
    logfile.close()
    
    batch_ms1=[]
    batch_auc=[]
    feature_info=np.zeros((total_feature, 4))
    count=-1
    for ftr in range (0, peptide_feature.shape[0]):
#        print(ftr)
        if peptide_feature[ftr, 5]==-1 or peptide_feature[ftr, 15]==-1:
            continue
         
        RT_peak=round(peptide_feature[ftr, 12], 2)
        if RT_peak in RT_index:
            RT_peak=RT_peak
        else:#select the closest and > RT_peak
            i=0
            while(i < len(RT_list) and RT_list[i]<=RT_peak):
                i=i+1
            if i ==len(RT_list):
                continue
            RT_peak=RT_list[i]
        
        # 7 step before, peak, 7 step after
        count=count+1 
        RT_s=max(RT_index[RT_peak]-7, 0)
        RT_e=min(RT_s+RT_window, len(RT_list)) #ex
        charge=int(peptide_feature[ftr, 3])
        num_isotopes=int(peptide_feature[ftr, 14])
        feature_width=min(total_frames_hor, num_isotopes)
        
#        before_10ppm=(peptide_feature[ftr, 0]*10.0)/10**6
        mz_s=round(max(peptide_feature[ftr, 0]-5*mz_unit, min_mz), mz_resolution)        
        feature_info[count, 0]=ftr
        feature_info[count, 1]=charge
        feature_info[count, 2]=feature_width
        feature_info[count, 3]=num_isotopes
        
        auc_list=[]
        for iso in range (0, num_isotopes):
            mz_point=int(round(((peptide_feature[ftr, 0]+iso*isotope_gap[charge])-min_mz)/mz_unit, mz_resolution))
            RT_start=RT_info[ftr][iso][0]
            RT_end=RT_info[ftr][iso][1]
            if RT_start in RT_index:
                RT_start=RT_start
            else:#select the closest and < RT_peak
                i=0
                while(i < len(RT_list) and RT_list[i]<RT_start):
                    RT_start_temp=RT_list[i]
                    i=i+1
                RT_start=RT_start_temp         
            
            if RT_end in RT_index:
                RT_end=RT_end
            else:#select the closest and < RT_peak
                i=0
                while(i < len(RT_list) and RT_list[i]<RT_end):
                    i=i+1
                RT_end=RT_list[i]
                
            rt_s=RT_index[RT_start]-rt_search_index
            rt_e=RT_index[RT_end]-rt_search_index
            y=np.array((np.copy(ms1[rt_s:rt_e+1, mz_point])/255)*maxI)
            x=np.array(RT_list[RT_index[RT_start]:RT_index[RT_end]+1])
            if x.shape[0]==1:
                auc_list.append(y)
            else: 
                auc_list.append(metrics.auc(x, y))            
        
        for iso in range (num_isotopes, total_frames_hor):
            auc_list.append(0)
            
        mz_e=mz_s
        for w in range (0, total_frames_hor):#feature_width):
            mz_e=round(mz_e+isotope_gap[charge], mz_resolution)
        #mz_e is inclusive    
            
        mz_start=mz_s  
        mz_end=round(mz_e+(mz_window-1)*mz_unit, mz_resolution) #in        
        cut_block=np.zeros((RT_window, int(round((mz_end-mz_start+mz_unit)/mz_unit, mz_resolution))))
###########################

        y=0
        for i in range (RT_s,  RT_e):
            j=0
            while(j<len(sorted_mz_list[i]) and sorted_mz_list[i][j][0]<=mz_start):
                if sorted_mz_list[i][j][0]==mz_start:
                    break
                j=j+1

            temp_dict=defaultdict(list)
            while(j<len(sorted_mz_list[i]) and sorted_mz_list[i][j][0]<=mz_end):
                temp_dict[sorted_mz_list[i][j][0]].append(sorted_mz_list[i][j][1])
                j=j+1
            
            temp_dict_keys=list(temp_dict.keys())
            for k in range (0, len(temp_dict)):
                temp_dict[temp_dict_keys[k]]=np.max(temp_dict[temp_dict_keys[k]])
                x=int(round((temp_dict_keys[k]-mz_start)/mz_unit, mz_resolution))
                cut_block[y, x]=temp_dict[temp_dict_keys[k]]                   
            # fill out the mz axis

            y=y+1                        
###########################
        min_I=0
        cut_block=((cut_block-min_I)/(maxI-min_I))*255
#        bt=np.copy(cut_block)     
#        max_I=np.amax(bt)
#        min_I=0
#        bt=((bt-min_I)/(max_I-min_I))*255
#        bt=255-bt
#        scipy.misc.imsave(datapath+'test.jpg', bt)        
        
#        
###########################                        
        batch_ms1.append(np.copy(cut_block)) 
        batch_auc.append(auc_list)
        
   
    print(len(batch_auc))
    print('writing data')     
#    f=open(datapath+'/feature_list/consecutiveScan_'+dataname[data_index]+'_combineIsotope_auc_info', 'wb')
#    pickle.dump(batch_auc, f, protocol=2)
    f=open(datapath+'/feature_list/consecutiveScan_'+dataname[data_index]+'_combineIsotope_dataset', 'wb')
    pickle.dump([batch_ms1, batch_auc, feature_info[0:len(batch_ms1), :]], f, protocol=2)
    f.close()   
    print('data write done')


