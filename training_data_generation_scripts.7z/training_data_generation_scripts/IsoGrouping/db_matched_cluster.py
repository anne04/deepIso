#scp -r fzohora@ming-gpu-1.cs.uwaterloo.ca:/data/fzohora/dilution_series_syn_pep/feature_list/130124_dilA_11_01_ms1_record  /home/anne/Desktop/bsi/update/130124_dilA_11_01_ms1_record
#scp -r fzohora@ming-gpu-1.cs.uwaterloo.ca:/data/fzohora/dilution_series_syn_pep/feature_list/130124_dilA_11_01_combineIsotopes_info  /home/anne/Desktop/bsi/update/130124_dilA_11_01_combineIsotopes_info
from __future__ import division
from __future__ import print_function
import tensorflow as tf
import math
from time import time
import pickle
import numpy as np
from collections import deque
from collections import defaultdict
import copy
import csv
import scipy.stats as stats
import sys
from sklearn import metrics

isotope_gap=np.zeros((10))
isotope_gap[0]=0.01
isotope_gap[1]=1.00
isotope_gap[2]=0.50
isotope_gap[3]=0.33
isotope_gap[4]=0.25
isotope_gap[5]=0.20
isotope_gap[6]=0.17
isotope_gap[7]=0.14
isotope_gap[8]=0.13
isotope_gap[9]=0.11

RT_window=15
mz_window=211
total_class=10
RT_unit=0.01
mz_unit=0.01

modelpath='/data/fzohora/dilution_series_syn_pep/model/'
datapath='/data/fzohora/dilution_series_syn_pep/'      #'/data/fzohora/water/' #'/media/anne/Study/study/PhD/bsi/update/data/water/'  #
dataname=['130124_dilA_8_01','130124_dilA_8_02', '130124_dilA_8_03', '130124_dilA_8_04', '130124_dilA_10_01','130124_dilA_10_02', '130124_dilA_10_03', '130124_dilA_10_04', '130124_dilA_11_01', '130124_dilA_11_02', '130124_dilA_11_03', '130124_dilA_11_04', '130124_dilA_12_01', '130124_dilA_12_02', '130124_dilA_12_03', '130124_dilA_12_04'] 

test_index=0 #int(sys.argv[1])

#print('scanning test ms: '+dataname[test_index])

###########################

mz_resolution=2

#############################

for test_index in range (1, 6):
    f=open(mappath+dataname[test_index]+'_pointNet_v3r2_clusters_mz3_v4', 'rb') # 98.35   
#    f=open(modelpath+dataname[test_index]+'_clusters_v2_sum', 'rb') 
    isotope_cluster_all, max_num_iso, total_cluster=pickle.load(f)
    f.close()
    isotope_cluster=defaultdict(list)
    print('scanning test ms: '+dataname[test_index])
    filename = datapath+'feature_list/'+dataname[test_index]+'_peptide.csv' 
    rows = []
    csvfile=open(filename, 'r')
    csvreader = csv.reader(csvfile)     
    for row in csvreader:
        rows.append(row)
    csvfile.close() 


    RT_tolerance=0.2
    tolerance_mz=0.01

    mz_list=sorted(isotope_cluster_all.keys())
    total_feature=0
    found_ftr=0
    found_poz=np.zeros((1,max_num_iso))

    for i in range (1, len(rows)):
        found=0
        mz_exact=round(float(rows[i][5]), mz_resolution)
        RT_peak=round(float(rows[i][6]), 2)
#        print(i)
        # see if this exist in any cluster
        matched_ftr=0
        for j in range (0, len(mz_list)):
            if mz_exact<round(mz_list[j]-tolerance_mz, mz_resolution):
                break
            ftr_list=isotope_cluster_all[mz_list[j]]
            for f in range (0, len(ftr_list)):
    #            print('j=%d f=%d'%(j, f))
                ftr=ftr_list[f]
                if round(ftr[int(len(ftr)-2)][0]+tolerance_mz , mz_resolution)< mz_exact:
                    continue
                for iso in range (0, len(ftr)-1):
                    iso_mz=round(ftr[iso][0], mz_resolution)
                    iso_RT_peak=round(ftr[iso][1][0], 2)
                    if round(mz_exact-tolerance_mz, mz_resolution)<=iso_mz and iso_mz <= round(mz_exact+tolerance_mz, mz_resolution):
                        if round(RT_peak-RT_tolerance, 2)<=iso_RT_peak and iso_RT_peak <= round(RT_peak+RT_tolerance, 2):
                            found=1
                            found_poz[0, iso]=found_poz[0, iso]+1
    #                        print('found at poz %d'%iso)
                            isotope_cluster[round(ftr[0][0], mz_resolution)].append(ftr) # starting m/z of the 1st isotope
                            matched_ftr=matched_ftr+1
                            break
    #            if found==1:   
    #                break
            
        if found==1:   
            found_ftr=found_ftr+1   
#            print('found with matching %d'%matched_ftr)
            
    print(found_ftr/(len(rows)-1))
    acc=found_ftr/(len(rows)-1)

    f=open(modelpath+dataname[test_index]+'_db_matched_cluster_v2_sum', 'wb') 
    pickle.dump([isotope_cluster, max_num_iso, acc], f, protocol=2)
    f.close()
    print('write done')

mz_list=sorted(isotope_cluster_all.keys())
total_ftr=0
for i in range (len(mz_list)):
    total_ftr=total_ftr+len(isotope_cluster_all[mz_list[i]])
    
print(total_ftr)

