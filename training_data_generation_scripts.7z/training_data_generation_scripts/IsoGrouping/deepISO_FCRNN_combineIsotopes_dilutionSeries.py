# without an extra blank window+eff
from __future__ import print_function, division
import numpy as np
import tensorflow as tf
#import matplotlib.pyplot as plt
import pickle
#import math
from time import time
import sys

isotope_gap=np.zeros((10))
isotope_gap[0]=0.01
isotope_gap[1]=100
isotope_gap[2]=50
isotope_gap[3]=33
isotope_gap[4]=25
isotope_gap[5]=20
isotope_gap[6]=17
isotope_gap[7]=14
isotope_gap[8]=13
isotope_gap[9]=11
#
truncated_backprop_length = 4
fc_size= 1024 
num_epochs= 100
learn_rate= 0.0001
batch_size=32
log_no='combine_isotopes_dilution_series_lr001_3fc_4conv_4tbp_fm8'
activation_func=2
#
#truncated_backprop_length = int(sys.argv[1]) #3
#fc_size= int(sys.argv[2]) #3 
#num_epochs= int(sys.argv[3])
#learn_rate= float(sys.argv[4])
#batch_size=int(sys.argv[5]) #128
#log_no=sys.argv[6] #128
#activation_func=int(sys.argv[7])

total_frames_hor=8
total_hops_horizontal= total_frames_hor//truncated_backprop_length 



#class_weight_variable = np.array([[.009, .3, .3, .3, .091/6, .091/6, .091/6, .091/6, .091/6, .091/6 ]]) #https://stackoverflow.com/questions/35155655/loss-function-for-class-imbalanced-binary-classifier-in-tensor-flow
#class_weight = tf.constant(class_weight_variable[0].tolist()) #https://stackoverflow.com/questions/35155655/loss-function-for-class-imbalanced-binary-classifier-in-tensor-flow


print('truncated_backprop_length %d, fc_size %d, learn_rate %g, batch_size %d'%(truncated_backprop_length,  fc_size,  learn_rate, batch_size))

RT_window=15
mz_window=211

############## load data #################
modelpath='/data/fzohora/dilution_series_syn_pep/model/'
datapath='/data/fzohora/dilution_series_syn_pep/'      #'/data/fzohora/water/' #'/media/anne/Study/study/PhD/bsi/update/data/water/'  #

dataname=['130124_dilA_10_02', '130124_dilA_10_03', '130124_dilA_10_04', '130124_dilA_11_01', '130124_dilA_11_02', '130124_dilA_11_03', '130124_dilA_11_04', '130124_dilA_12_01', '130124_dilA_12_02', '130124_dilA_12_03', '130124_dilA_12_04'] 


# merge all training ms1 labels
#merged_label = np.zeros((batch_size, label.shape[0]+RT_window, label.shape[1]+mz_window, num_class))
#merged_label[:, :, 0]=1
#merged_label[0, 0:label.shape[0], 0:label.shape[1], :]=label
#pad ms1 in top and right boundary to match with trancated propagated length 
#merge all ms1
#merged_ms1= np.zeros((batch_size,ms1.shape[0]+RT_window, ms1.shape[1]+mz_window))
#merged_ms1[0, 0:ms1.shape[0], 0:ms1.shape[1]]= ms1

#########Create Log##############################################################
logfile=open(modelpath+'deepISO_performance_'+log_no+'.csv', 'wb')
logfile.close()

logfile=open(modelpath+'deepISO_class_loss_'+log_no+'.csv', 'wb')
logfile.close()

#######################################################################
num_class=2
state_size = fc_size
num_neurons= num_class #mz_window*RT_window




def weight_variable(shape, variable_name):
    initial = tf.truncated_normal(shape, stddev=0.1)
    return tf.Variable(initial, name=variable_name)

def bias_variable(shape, variable_name):
    initial = tf.constant(0.1, shape=shape)
    return tf.Variable(initial, name=variable_name)

def conv2d(x, W):
    return tf.nn.conv2d(x, W, strides=[1, 1, 1, 1], padding='VALID')

def max_pool_2x2(x):
    return tf.nn.max_pool(x, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')

batchX_placeholder = tf.placeholder(tf.float32, [batch_size, RT_window, mz_window*truncated_backprop_length]) #image block to consider for one run of training by back propagation
keep_prob = tf.placeholder(tf.float32)
# each image is 15 x 211


W_conv0 = weight_variable([8, 22 , 1, 16], 'W_conv0')#v10: 
b_conv0 = bias_variable([16], 'b_conv0') #for each of feature maps

W_conv1 = weight_variable([4, 6 , 16, 32], 'W_conv1')#v10: 
b_conv1 = bias_variable([32], 'b_conv1') #for each of feature maps

W_conv2 = weight_variable([3, 4, 32, 64], 'W_conv2')  
b_conv2 = bias_variable([64], 'b_conv2') 

W_conv3 = weight_variable([3, 3, 64, 128], 'W_conv3')  
b_conv3 = bias_variable([128], 'b_conv3')

#W_fc1 = weight_variable([1 * 180 * 128, 512], 'W_fc1')
#b_fc1 = bias_variable([512], 'b_fc1')


W_fc1 = weight_variable([1 * 180 * 128, 264], 'W_fc1')
b_fc1 = bias_variable([264], 'b_fc1')

W_fc2 = weight_variable([264, 512], 'W_fc2')
b_fc2 = bias_variable([512], 'b_fc2')

#W_out = weight_variable([1 * 180 * 128, fc_size], 'W_out')
W_out = weight_variable([512, fc_size], 'W_out')
b_out = bias_variable([fc_size], 'b_out')

#param_loader = tf.train.Saver({'W_conv0': W_conv0, 'W_conv1': W_conv1, 'W_conv2': W_conv2, 'W_conv3': W_conv3, 'W_fc1':W_fc1, 'W_out':W_out, 'b_conv0':b_conv0, 'b_conv1':b_conv1, 'b_conv2':b_conv2, 'b_conv3':b_conv3, 'b_fc1':b_fc1, 'b_out':b_out})

batchY_placeholder = tf.placeholder(tf.float32, [batch_size, truncated_backprop_length, num_class])

init_state = tf.placeholder(tf.float32, [batch_size, state_size])

W = tf.Variable(np.random.rand(state_size, state_size), dtype=tf.float32) 

W2 = tf.Variable(np.random.rand(state_size, num_class),dtype=tf.float32) #final output
b2 = tf.Variable(np.zeros((1,num_class)), dtype=tf.float32) #final output

# Unpack columns
#labels_series = tf.unpack(batchY_placeholder, axis=1)

# Forward pass
current_state = init_state
states_series = []
for j in range (0, truncated_backprop_length):
    ##############################
    x_image = tf.reshape(batchX_placeholder[:, : , mz_window*j : mz_window* (j+1)], [batch_size, RT_window, mz_window, 1]) #flatten to 2d: row: RT, column: mz
            
    if (activation_func==1):       
        h_conv0 = tf.nn.relu(conv2d(x_image, W_conv0) + b_conv0) # now the input is: (15-8+1) x (211-22+1) x 16 = 8 x 190 x 16
        h_conv1 = tf.nn.relu(conv2d(h_conv0, W_conv1) + b_conv1) # now the input is: (8-4+1) x (190-6+1) x 16 = 5 x 185 x 16
        h_conv2 = tf.nn.relu(conv2d(h_conv1, W_conv2) + b_conv2) # now the input is: (5-3+1) x (185-4+1) x 8 = 3  x 182  x 8
        h_conv3 = tf.nn.relu(conv2d(h_conv2, W_conv3) + b_conv3) #3-3+1 x 182-3+1 x 8 = 1 x 180 x 8
        h_conv3_flat = tf.reshape(h_conv3, [batch_size, 1 * 180  * 128])
        h_conv3_flat_drop = tf.nn.dropout(h_conv3_flat, keep_prob)
        h_fc1 = tf.nn.relu(tf.matmul(h_conv3_flat_drop, W_fc1) + b_fc1) # finally giving the output
        h_fc2 = tf.nn.relu(tf.matmul(h_fc1, W_fc2) + b_fc2) # finally giving the output
        y_conv = tf.nn.relu(tf.matmul(h_fc2, W_out) + b_out) # finally giving the output
        ##############################
        current_FC  =  tf.nn.dropout(y_conv, keep_prob) # [batch_size, fc_size])
        weighted_state = tf.matmul(current_state, W) # Broadcasted addition #shape?? # EDIT
        next_state = tf.nn.relu(weighted_state + current_FC)  # Broadcasted addition #shape?? # EDIT
    else:   
        h_conv0 = tf.tanh(conv2d(x_image, W_conv0) + b_conv0) # now the input is: (15-8+1) x (211-22+1) x 16 = 8 x 190 x 16
        h_conv1 = tf.tanh(conv2d(h_conv0, W_conv1) + b_conv1) # now the input is: (8-4+1) x (190-6+1) x 16 = 5 x 185 x 16
        h_conv2 = tf.tanh(conv2d(h_conv1, W_conv2) + b_conv2) # now the input is: (5-3+1) x (185-4+1) x 8 = 3  x 182  x 8
        h_conv3 = tf.tanh(conv2d(h_conv2, W_conv3) + b_conv3) #3-3+1 x 182-3+1 x 8 = 1 x 180 x 8
        h_conv3_flat = tf.reshape(h_conv3, [batch_size, 1 * 180  * 128])
        h_conv3_flat_drop = tf.nn.dropout(h_conv3_flat, keep_prob)
        h_fc1 = tf.tanh(tf.matmul(h_conv3_flat_drop, W_fc1) + b_fc1) # finally giving the output
        h_fc2 = tf.tanh(tf.matmul(h_fc1, W_fc2) + b_fc2) # finally giving the output
        y_conv = tf.tanh(tf.matmul(h_fc2, W_out) + b_out) # finally giving the output
        ##############################
        current_FC  =  tf.nn.dropout(y_conv, keep_prob) # [batch_size, fc_size])
        weighted_state = tf.matmul(current_state, W) # Broadcasted addition #shape?? # EDIT
        next_state = tf.tanh(weighted_state + current_FC)  # Broadcasted addition #shape?? # EDIT
        
    states_series.append(next_state)
    current_state = next_state

logits_series = [tf.matmul(state, W2) + b2 for state in states_series] #Broadcasted addition
#predictions_series = [tf.nn.softmax(logits) for logits in logits_series]
predictions_series = [tf.argmax(tf.nn.softmax(logits), 1) for logits in logits_series]

loss_series=[]
for col in range(0,  truncated_backprop_length):
    loss_series.append(tf.nn.softmax_cross_entropy_with_logits(logits=logits_series[col], labels=batchY_placeholder[:, col, :]))  
    
total_loss = tf.reduce_mean(loss_series)

train_step = tf.train.AdagradOptimizer(learn_rate).minimize(total_loss)


####################################################################################
#sess = tf.Session()
#sess.run(tf.global_variables_initializer())

config=tf.ConfigProto(log_device_placement=True)
config.gpu_options.allow_growth = True
sess = tf.Session(config=config)
sess.run(tf.global_variables_initializer())
#test_index=4
#print(sess.run(W_conv0))
saver = tf.train.Saver()
saver.save(sess, modelpath+'init-model_deepISO_FCRNN_water_'+log_no+'.ckpt')
#saver.restore(sess, logsave+"my-model_test1_highneg.ckpt")
#param_loader.restore(sess, modelpath+'FCRNN_pretrain_water_test_'+str(test_index)+'.ckpt')
#x,y = generateData()
################ training ############################################################
min_loss=100
start_time=time()
with sess.as_default():    
    for epoch_idx in range(0, num_epochs):
        # go to each feature
        print("epoch", epoch_idx)
        count_batch=0
        for data_index in range (3, len(dataname)):
            f=open(datapath+'/feature_list/'+dataname[data_index]+'_combineIsotope_dataset', 'rb')
            cut_ms1, feature_info = pickle.load(f)
            f.close()   
            total_feature=len(cut_ms1)
            number_of_batch=total_feature//batch_size
            count_batch=count_batch+number_of_batch
            random_pick=np.random.permutation(len(cut_ms1))
            r=-1
            for batch_idx in range (0,  number_of_batch):
                batch_ms1=np.zeros((batch_size, RT_window,mz_window*total_frames_hor))
                batch_label=np.zeros((batch_size, 1, total_frames_hor, num_class))            
                batch_predictions=np.zeros((batch_size, 1, total_frames_hor))  
                count=0
                while count!=batch_size :
                    r=r+1
                    ftr=random_pick[r]

                    charge=int(feature_info[ftr, 1])
                    feature_width=int(feature_info[ftr, 2]) # number of isotopes
                    frame_count=int(feature_info[ftr, 3])
                    mz_start=0
                    for i in range (0, frame_count):
                        batch_ms1[count,:, (i)*mz_window:(i+1)*mz_window]=np.copy(cut_ms1[ftr][:,mz_start:mz_start+mz_window])                                                
                        mz_start=int(mz_start+isotope_gap[charge])
                        
                    # learn to say 'no', when 1st isotope of adjacent feature is seen
                    batch_label[count, 0, 0:feature_width, 1]=1
                    batch_label[count, 0, 0:feature_width, 0]=0
                    batch_label[count, 0, feature_width:, 0]=1
                        
                    count=count+1

                # one batch is formed
#                print('batch %d is formed'%batch_idx)
                avg_loss=0
                accuracy_measure=np.zeros((1, num_class+2))
                confusion_matrix=np.zeros((num_class, num_class))
                real_class=np.zeros((num_class))
#                class_loss=np.zeros((1, num_class))
                _current_state = np.zeros((batch_size, state_size))               
                for col_idx in range(0,total_hops_horizontal): # total_hops_horizontal=87 in each hop, 6 windows are considered as truncated backprop length is 6
                    start_col=col_idx * truncated_backprop_length * mz_window # 
                    end_col= start_col + truncated_backprop_length * mz_window # 
                    
                    batchX = batch_ms1[:,:, start_col:end_col]
                    
                    label_start_column = col_idx * truncated_backprop_length
                    label_end_column = label_start_column + truncated_backprop_length
                    
                    batchY = batch_label[:,0, label_start_column:label_end_column]
                    
                    _total_loss, _train_step, _current_state, _predictions_series = sess.run(
                        [total_loss, train_step, current_state, predictions_series],
                        feed_dict={
                            batchX_placeholder:batchX,
                            batchY_placeholder:batchY ,
                            init_state:_current_state, 
                            keep_prob:0.5
                        })                                        
    #                print("hello")
    #                print(sess.run(W))
                    
                    avg_loss=avg_loss+_total_loss
                    if batch_idx%10==0:
                        for b in range (0, batch_size):
                                for col in range(0,  truncated_backprop_length):
                                    batch_predictions[b,0, label_start_column+col]=int(_predictions_series[col][b])

                #one batch is done   
                if batch_idx%10==0:
                    feature_detect=0
                    for b in range (0, batch_size):
                        for col in range(0,  total_frames_hor):                    
                            real_charge=int(np.argmax(batch_label[b, 0, col]))
                            pred_charge=int(batch_predictions[b,0, col])
                            real_class[real_charge]=real_class[real_charge]+1
                            confusion_matrix[real_charge, pred_charge]=confusion_matrix[real_charge, pred_charge]+1                            

                        flag=1
                        iso_count=0
                        for col in range(0,  total_frames_hor):
                            real_charge=int(np.argmax(batch_label[b, 0, col]))
                            pred_charge=int(batch_predictions[b, 0, col])                            
                            if real_charge==1 and pred_charge==1:
                                iso_count=iso_count+1
                                
                            elif real_charge==1 and pred_charge==0:
                                if (col+1)<total_frames_hor and int(np.argmax(batch_label[b, 0, col+1]))==0:
                                    flag=2
                                else:
                                    flag=0
                                break
                            elif real_charge==0:
                                break
                        if flag==1 or flag==2 or iso_count>=3:
                            feature_detect=feature_detect+1                        
                        
                    avg_loss=avg_loss/total_hops_horizontal    
                    feature_detect=feature_detect/batch_size
                    for i in range (0, num_class):
                        print("avg accuracy for z=%d is %g, amount %d"%(i, confusion_matrix[i, i]/real_class[i], real_class[i]))
                        accuracy_measure[0, i]=confusion_matrix[i, i]/real_class[i]

                        
                    accuracy_measure[0, num_class]=avg_loss
                    accuracy_measure[0, num_class+1]=feature_detect
                    print('for epoch %d, batch %d, avg loss %g, feature detection %g'%(epoch_idx,batch_idx, avg_loss, feature_detect) )    
                    logfile=open(modelpath+'deepISO_performance_'+log_no+'.csv', 'ab')
                    np.savetxt(logfile,accuracy_measure, delimiter=',')
                    logfile.close() 
                    
#                    logfile=open(modelpath+'deepISO_class_loss_'+log_no+'.csv', 'ab')
#                    np.savetxt(logfile,class_loss, delimiter=',')
#                    logfile.close()                      

                    if avg_loss<=min_loss:
                        min_loss=avg_loss
                        #save the model
                        saver.save(sess, modelpath+'trained-model_deepISO_FCRNN_water_'+log_no+'.ckpt')
        print(count_batch*batch_size)







