from __future__ import division
import pickle
import numpy as np
import scipy.misc
import math
import gc
from collections import defaultdict

RT_unit=.01
mz_unit=.01
mz_resolution=2
datapath='/data/fzohora/dilution_series_syn_pep/'      #'/data/fzohora/water/' #'/media/anne/Study/study/PhD/bsi/update/data/water/'  #
dataname=['130124_dilA_10_01','130124_dilA_10_02', '130124_dilA_10_03', '130124_dilA_10_04', '130124_dilA_11_01', '130124_dilA_11_02', '130124_dilA_11_03', '130124_dilA_11_04', '130124_dilA_12_01', '130124_dilA_12_02', '130124_dilA_12_03', '130124_dilA_12_04'] 
#mz_window=211
RT_window=15
total_frames_hor=6


isotope_gap=np.zeros((10))
isotope_gap[0]=0.001
isotope_gap[1]=1.00
isotope_gap[2]=.50
isotope_gap[3]=.33
isotope_gap[4]=.25
isotope_gap[5]=.20
isotope_gap[6]=.17
isotope_gap[7]=.14
isotope_gap[8]=.13
isotope_gap[9]=.11





total_charge=10
class_type=np.zeros((total_charge))
class_type[1]=50000
class_type[2]=50000
class_type[3]=50000 #16000
class_type[4]=50000
class_type[5]=10000
class_type[6]=3000
class_type[7]=2000
class_type[8]=2000
class_type[9]=2000
##5909+18518+4293+350+30+3
#########################################################################
#
total_cand_feature=0
for data_index in range (4, 12):
    print(dataname[data_index])
    
    logfile=open(datapath+'feature_list/'+dataname[data_index]+'_combineIsotopes_featureList.csv', 'rb')
    peptide_feature=np.loadtxt(logfile, delimiter=',')
    logfile.close()

    f=open(datapath+'feature_list/'+dataname[data_index]+'_ms1_record', 'rb')
    RT_mz_I_dict, maxI=pickle.load(f)
    f.close()   

    print('feature list loaded')
        
    RT_list = np.sort(list(RT_mz_I_dict.keys()))
    max_RT=RT_list[len(RT_list)-1]
    min_RT=10
        

    RT_index=dict()
    for i in range(0, RT_list.shape[0]):
        RT_index[round(RT_list[i], 2)]=i    

    list_zero_candidate=[]  
    total_feature=peptide_feature.shape[0]
    for i in range (0, total_feature):
        if peptide_feature[i, 5]==-1 or peptide_feature[i, 15]==-1: #avoided for some reason
            continue
            
        charge=int(peptide_feature[i, 3])
        if class_type[charge]<=0:
            continue        

        if peptide_feature[i, 1] not in RT_index or peptide_feature[i, 2] not in RT_index:
            continue # for simplicity
            
        if round(peptide_feature[i, 12], 2)==0:
            continue # for simplicity or bugs?
            
        flag=0            
        #A:
        rt_bottom=peptide_feature[i, 1]  #inclusive
        rt_top=peptide_feature[i, 2]   #inclusive

        mz_left=round(peptide_feature[i, 0]-isotope_gap[charge]*2-5*mz_unit, 2)
        mz_right=round(peptide_feature[i, 0]+5*mz_unit, 2)

        for j in range (0, total_feature):
            if i==j:
                continue
    #        if (RectA.Left < RectB.Right && RectA.Right > RectB.Left && RectA.Top > RectB.Bottom && RectA.Bottom < RectB.Top ) # A=i, B=j
            if mz_left<=peptide_feature[j, 6]  and mz_right>=peptide_feature[j, 0] and rt_top>=peptide_feature[j, 7] and rt_bottom<=peptide_feature[j, 8] : #yes to overlap
#            if mz_left>peptide_feature[j, 6]  or mz_right<peptide_feature[j, 0] or rt_top<peptide_feature[j, 7] or rt_bottom>peptide_feature[j, 8] :                
                flag=1
                break
        if flag==1:
#            print(i)
            list_zero_candidate.append(i)   #(ftr)
            class_type[charge]=class_type[charge]-1

    zero_candidate=np.zeros((len(list_zero_candidate), peptide_feature.shape[1]+1))
    for i in range (0, len(list_zero_candidate)):
        zero_candidate[i, 0:peptide_feature.shape[1]]=np.copy(peptide_feature[list_zero_candidate[i], :])
        zero_candidate[i, peptide_feature.shape[1]]=list_zero_candidate[i]
    #    zero_candidate[i, 5]=list_zero_candidate[i]+1

    total_cand_feature=total_cand_feature+zero_candidate.shape[0]
    f=open(datapath+'feature_list/'+dataname[data_index]+'_isoCombine_zero_candidate_overlap.csv', 'wb')
    np.savetxt(f, zero_candidate, delimiter=',')
    f.close()   

    print('zero cand overlap saved: %d class_type[2] is %d class_type[3] is %d'%(total_cand_feature,class_type[2],class_type[3]))


RT_window=15
mz_window=11
mz_unit=0.01
RT_unit=0.01
mz_resolution=2

frames_before=np.random.randint(1, size=total_cand_feature)
zero_ftr=0
for data_index in range (8, len(dataname)):
    print(dataname[data_index])
    logfile=open(datapath+'feature_list/'+dataname[data_index]+'_isoCombine_zero_candidate_overlap.csv', 'rb')
    peptide_feature=np.loadtxt(logfile, delimiter=',')
    logfile.close()
    print('zero cand list loaded')

    f=open(datapath+'feature_list/'+dataname[data_index]+'_ms1_record', 'rb')
    RT_mz_I_dict, maxI=pickle.load(f)
    f.close()   

    print('ms1 record load done')
        
    RT_list = np.sort(list(RT_mz_I_dict.keys()))
    max_RT=RT_list[len(RT_list)-1]
    min_RT=10
        

    RT_index=dict()
    for i in range(0, RT_list.shape[0]):
        RT_index[round(RT_list[i], 2)]=i    

    sorted_mz_list=[]
    for i in range (0, len(RT_list)):
            #make the sorted list as well
        sorted_mz_list.append(sorted(RT_mz_I_dict[RT_list[i]]))
        
    zero_data=[]
    map_to_peaks=[]
    num_class=10
    count=0
    feature_info=np.zeros((peptide_feature.shape[0], 4))
    for ftr in range (0, peptide_feature.shape[0]):
#        print(ftr)
        if peptide_feature[ftr, 1]<10.0:
            continue

        RT_peak=round(peptide_feature[ftr, 12], 2)
        if RT_peak in RT_index:
            RT_peak=RT_peak
        else:#select the closest and > RT_peak
            i=0
            while(i < len(RT_list) and RT_list[i]<=RT_peak):
                i=i+1
            RT_peak=RT_list[i]
        
        # 7 step before, peak, 7 step after
        RT_s=max(RT_index[RT_peak]-7, 0)
        RT_e=min(RT_s+RT_window, len(RT_list)) #ex
        charge=int(peptide_feature[ftr, 3])
        num_isotopes=int(peptide_feature[ftr, 14])
        feature_width=0 #label zero
        
        mz_s=round(peptide_feature[ftr, 0]-isotope_gap[charge]*(frames_before[zero_ftr]+1)-5*mz_unit, mz_resolution)
            
        mz_e=mz_s
        for w in range (0, total_frames_hor):#feature_width):
            mz_e=round(mz_e+isotope_gap[charge], mz_resolution)
        #mz_e is inclusive    

        mz_start=mz_s  
        mz_end=round(mz_e+(mz_window-1)*mz_unit, mz_resolution) #in        
        cut_block=np.zeros((RT_window, int(round((mz_end-mz_start+mz_unit)/mz_unit, mz_resolution))))
    #    
        y=0
        for i in range (RT_s,  RT_e):
            j=0
            while(j<len(sorted_mz_list[i]) and sorted_mz_list[i][j][0]<=mz_start):
                if sorted_mz_list[i][j][0]==mz_start:
                    break
                j=j+1

            temp_dict=defaultdict(list)
            while(j<len(sorted_mz_list[i]) and sorted_mz_list[i][j][0]<=mz_end):
                temp_dict[sorted_mz_list[i][j][0]].append(sorted_mz_list[i][j][1])
                j=j+1

            temp_dict_keys=list(temp_dict.keys())
            for k in range (0, len(temp_dict)):
                temp_dict[temp_dict_keys[k]]=np.max(temp_dict[temp_dict_keys[k]])
                x=int(round((temp_dict_keys[k]-mz_start)/mz_unit, mz_resolution))
                cut_block[y, x]=temp_dict[temp_dict_keys[k]]
            # fill out the mz axis

            y=y+1 

        min_I=0
        cut_block=((cut_block-min_I)/(maxI-min_I))*255
    #        bt=np.copy(cut_block)     
    #        max_I=np.amax(bt)
    #        min_I=0
    #        bt=((bt-min_I)/(max_I-min_I))*255
    #        bt=255-bt
    #        scipy.misc.imsave(datapath+'test.jpg', bt)        

    #        
    ###########################
        zero_data.append(np.copy(cut_block))         
        feature_info[count, 0]=ftr
        feature_info[count, 1]=charge
        feature_info[count, 2]=feature_width    
        zero_ftr=zero_ftr+1
        count=count+1 

    print('zero data write')
    print(len(zero_data))
    f=open(datapath+'cut_features/'+dataname[data_index]+'_isoCombine_zerodata_overlap', 'wb')
    pickle.dump([zero_data, feature_info] , f,protocol=2)
    f.close()
    print('zero data write done')



#
#f=open(datapath+'cut_features/'+dataname[data_index]+'_zerodata_2', 'wb')
#pickle.dump(zero_data[50000:], f,protocol=2)
#f.close()

#f=open(path+'cutfeatures/'+dataname[data_index]+'_zerodata_1', 'wb')
#pickle.dump([zero_data[0:100000], zero_data_label[0:100000]], f)
#f.close()
#f=open(path+'cutfeatures/'+dataname[data_index]+'_zerodata_2', 'wb')
#pickle.dump([zero_data[100000:200000], zero_data_label[100000:200000]], f)
#f.close()
#f=open(path+'cutfeatures/'+dataname[data_index]+'_zerodata_3', 'wb')
#pickle.dump([zero_data[200000:300000], zero_data_label[200000:300000]], f)
#f.close()
#
#
#



