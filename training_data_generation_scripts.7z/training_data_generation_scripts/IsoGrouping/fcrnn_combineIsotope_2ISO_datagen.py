from __future__ import division
from __future__ import print_function
import math
import numpy as np
import csv
import scipy.misc
import pickle
import pandas as pd
#from shapely.geometry import Polygon
import gc
from collections import defaultdict

datapath='/data/fzohora/dilution_series_syn_pep/'      #'/data/fzohora/water/' #'/media/anne/Study/study/PhD/bsi/update/data/water/'  #
dataname=['130124_dilA_10_01','130124_dilA_10_02', '130124_dilA_10_03', '130124_dilA_10_04', '130124_dilA_11_01', '130124_dilA_11_02', '130124_dilA_11_03', '130124_dilA_11_04', '130124_dilA_12_01', '130124_dilA_12_02', '130124_dilA_12_03', '130124_dilA_12_04'] 
#sample=['130124_dilA_10_02.ms1']#,  'Demo_LC_Chymotrypsin.ms1',  'Demo_LC_Trypsin.ms1',  'Demo_HC_AspN.ms1',  'Demo_HC_Chymotrypsin.ms1', 'Demo_HC_Trypsin.ms1'] 


RT_window=15
mz_window=11 #2031
total_frames_hor=8
RT_unit=0.01
mz_unit=0.01
mz_resolution=2


isotope_gap=np.zeros((10))
isotope_gap[0]=0.001
isotope_gap[1]=1.00
isotope_gap[2]=.50
isotope_gap[3]=.33
isotope_gap[4]=.25
isotope_gap[5]=.20
isotope_gap[6]=.17
isotope_gap[7]=.14
isotope_gap[8]=.13
isotope_gap[9]=.11

total_2ISO_feature=60000
batch_ms1=[]
count=-1
feature_info=np.zeros((total_2ISO_feature, 4))
for data_index in range(4, len(dataname)):

    print('count %d'%count)
    
    print(dataname[data_index])            

    f=open(datapath+'feature_list/'+dataname[data_index]+'_ms1_record', 'rb')
    RT_mz_I_dict, maxI=pickle.load(f)
    f.close()   

    print('ms1 record load done')
    f=open(datapath+'feature_list/'+dataname[data_index]+'_combineIsotopes_info', 'rb')
    total_feature,  maxI=pickle.load(f)
    f.close() 
    
    RT_list = np.sort(list(RT_mz_I_dict.keys()))
    max_RT=RT_list[len(RT_list)-1]
    min_RT=10.0

    RT_index=dict()
    sorted_mz_list=[]
    for i in range(0, RT_list.shape[0]):
        RT_index[round(RT_list[i], 2)]=i
        sorted_mz_list.append(sorted(RT_mz_I_dict[RT_list[i]]))
    
    max_mz=0
    min_mz=1000
    for i in range(0, RT_list.shape[0]):
        mz_I_list=sorted_mz_list[i]
        mz=mz_I_list[len(mz_I_list)-1][0]
        if mz>max_mz:
            max_mz=mz
        mz=mz_I_list[0][0]
        if mz<min_mz:
            min_mz=mz

    logfile=open(datapath+'feature_list/'+dataname[data_index]+'_combineIsotopes_featureList.csv', 'rb')
    peptide_feature=np.loadtxt(logfile, delimiter=',')
    logfile.close()    

    for ftr in range (0, peptide_feature.shape[0]):
#        print(ftr)
        if peptide_feature[ftr, 5]==-1 or peptide_feature[ftr, 14]>2:
            continue
         
        RT_peak=round(peptide_feature[ftr, 12], 2)
        if RT_peak in RT_index:
            RT_peak=RT_peak
        else:#select the closest and > RT_peak
            i=0
            while(i < len(RT_list) and RT_peak<=RT_list[i]):
                i=i+1
            if i ==len(RT_list):
                continue
            RT_peak=RT_list[i]
        
        # 7 step before, peak, 7 step after
        count=count+1 
        RT_s=max(RT_index[RT_peak]-7, 0)
        RT_e=min(RT_s+RT_window, len(RT_list)) #ex
        charge=int(peptide_feature[ftr, 3])
        num_isotopes=int(peptide_feature[ftr, 14])
        feature_width=min(total_frames_hor, num_isotopes)
        
#        before_10ppm=(peptide_feature[ftr, 0]*10.0)/10**6
        mz_s=round(max(peptide_feature[ftr, 0]-5*mz_unit, min_mz), mz_resolution)                
        mz_e=mz_s
        for w in range (0, total_frames_hor):#feature_width):
            mz_e=round(mz_e+isotope_gap[charge], mz_resolution)
        #mz_e is inclusive    
            
        mz_start=mz_s  
        mz_end=round(mz_e+(mz_window-1)*mz_unit, mz_resolution) #in        
        cut_block=np.zeros((RT_window, int(round((mz_end-mz_start+mz_unit)/mz_unit, mz_resolution))))
###########################

        y=0
        for i in range (RT_s,  RT_e):
            j=0
            while(j<len(sorted_mz_list[i]) and sorted_mz_list[i][j][0]<=mz_start):
                if sorted_mz_list[i][j][0]==mz_start:
                    break
                j=j+1

            temp_dict=defaultdict(list)
            while(j<len(sorted_mz_list[i]) and sorted_mz_list[i][j][0]<=mz_end):
                temp_dict[sorted_mz_list[i][j][0]].append(sorted_mz_list[i][j][1])
                j=j+1
            
            temp_dict_keys=list(temp_dict.keys())
            for k in range (0, len(temp_dict)):
                temp_dict[temp_dict_keys[k]]=np.max(temp_dict[temp_dict_keys[k]])
                x=int(round((temp_dict_keys[k]-mz_start)/mz_unit, mz_resolution))
                cut_block[y, x]=temp_dict[temp_dict_keys[k]]                   
            # fill out the mz axis

            y=y+1                        
###########################
        min_I=0
        cut_block=((cut_block-min_I)/(maxI-min_I))*255
#        bt=np.copy(cut_block)     
#        max_I=np.amax(bt)
#        min_I=0
#        bt=((bt-min_I)/(max_I-min_I))*255
#        bt=255-bt
#        scipy.misc.imsave(datapath+'test.jpg', bt)        
        
#        
###########################                        
        batch_ms1.append(np.copy(cut_block)) 
        feature_info[count, 0]=ftr
        feature_info[count, 1]=charge
        feature_info[count, 2]=feature_width
        
        if count==total_2ISO_feature-1:
            break 
            
    if count==total_2ISO_feature-1:
        break


print(len(batch_ms1))
print('writing data')     
f=open(datapath+'/feature_list/consecutiveScan_'+dataname[data_index]+'_combineIsotope_2ISO_dataset', 'wb')
pickle.dump([batch_ms1, feature_info[0:len(batch_ms1), :]], f, protocol=2)
f.close()   
print('data write done')


