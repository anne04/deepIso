from __future__ import division
import pickle
import numpy as np
import scipy.misc
import math
import gc
from collections import defaultdict

RT_unit=.01 
mz_unit=.01

datapath='/data/fzohora/dilution_series_syn_pep/'      #'/data/fzohora/water/' #'/media/anne/Study/study/PhD/bsi/update/data/water/'  #
dataname=['130124_dilA_10_01','130124_dilA_10_02', '130124_dilA_10_03', '130124_dilA_10_04', '130124_dilA_11_01', '130124_dilA_11_02', '130124_dilA_11_03', '130124_dilA_11_04', '130124_dilA_12_01', '130124_dilA_12_02', '130124_dilA_12_03', '130124_dilA_12_04'] 
data_index=4


########################################################################
mz_window=211
RT_window=15
total_frames_var=20

f=open(datapath+'feature_list/'+dataname[data_index]+'_ms1_record', 'rb')
RT_mz_I_dict, maxI=pickle.load(f)
f.close()   

print('feature list loaded')
    
RT_list = np.sort(list(RT_mz_I_dict.keys()))
max_RT=RT_list[len(RT_list)-1]
min_RT=10
    

RT_index=dict()
for i in range(0, RT_list.shape[0]):
    RT_index[round(RT_list[i], 2)]=i    


f=open(datapath+'feature_list/'+dataname[data_index]+'_ms1_record', 'rb')
RT_mz_I_dict, maxI=pickle.load(f)
f.close()   

print('ms1 record load done')

RT_list = np.sort(list(RT_mz_I_dict.keys()))
max_RT=RT_list[len(RT_list)-1]
min_RT=10
RT_window=20
mz_window=211
mz_unit=0.01
RT_unit=0.01
mz_resolution=2


    
RT_list = np.sort(list(RT_mz_I_dict.keys()))
max_RT=RT_list[len(RT_list)-1]
min_RT=10
    

RT_index=dict()
for i in range(0, RT_list.shape[0]):
    RT_index[round(RT_list[i], 2)]=i    

sorted_mz_list=[]
for i in range (0, len(RT_list)):
        #make the sorted list as well
    sorted_mz_list.append(sorted(RT_mz_I_dict[RT_list[i]]))

rt_search_index=0
zero_data=[]
zero_label=[]
map_to_peaks=[]
sequence_length=[]
num_class=10
real_class=np.zeros((num_class))
zero_data_amount=2000
zero_data_stripe=0

charge=0

mz_start=1916.2 #800
mz_end=round(mz_start+(mz_window*3)*mz_unit, mz_resolution)
RT_start=RT_index[105.50]
RT_end=min(RT_start+(total_frames_var*4)-1+(RT_window-1),len(RT_list)-1) # inclusive

cut_block=np.zeros((total_frames_var*4+RT_window-1,mz_window*3))    
###########################
i=RT_start
y=0
while(i<=RT_end):
    rt=RT_list[i]
    k=i
    j=0
    while(j<len(sorted_mz_list[k]) and sorted_mz_list[k][j][0]<=mz_start):
        if sorted_mz_list[k][j][0]==mz_start:
            break
        j=j+1

    temp_dict=defaultdict(list)
    while(j<len(sorted_mz_list[k]) and sorted_mz_list[k][j][0]<=mz_end):
        temp_dict[sorted_mz_list[k][j][0]].append(sorted_mz_list[k][j][1])
        j=j+1
    
    temp_dict_keys=list(temp_dict.keys())
    for k in range (0, len(temp_dict)):
        temp_dict[temp_dict_keys[k]]=np.max(temp_dict[temp_dict_keys[k]])
    
    # fill out the mz axis
    mz=mz_start
    for x in range (0, cut_block.shape[1]):
        if mz in temp_dict_keys:
            cut_block[y, x]=temp_dict[mz]
        mz=round(mz+mz_unit, mz_resolution)
    
    i=i+1
    y=y+1                        
###########################
min_I=0
cut_block=((cut_block-min_I)/(maxI-min_I))*255
    
#bt=np.copy(cut_block)     
#bt=255-bt
#scipy.misc.imsave(datapath+'TN.jpg', bt)        
    
for row_idx in range (0, 58): # say NO
    row=row_idx*1
    for col_idx in range (0, 350): # say NO
        col=col_idx*1
        zero_data.append(cut_block[row:row+total_frames_var+(RT_window-1), col:col+mz_window])
        zero_label.append(np.zeros((total_frames_var)))
        sequence_length.append(total_frames_var)
        real_class[0]=real_class[0]+total_frames_var
#        if row_idx==0:
#            bt=np.copy(np.copy(cut_block[row:row+total_frames_var+(RT_window-1), col:col+mz_window]))     
#            bt=255-bt
#            scipy.misc.imsave(datapath+'TN'+str(zero_data_stripe)+'.jpg', bt)        
        zero_data_stripe=zero_data_stripe+1
        
        
print('zero data write %d'%zero_data_stripe)
f=open(datapath+'cut_features/'+dataname[data_index]+'_zerodata_TN_stripe', 'wb')
pickle.dump([zero_data, zero_label, sequence_length, map_to_peaks, real_class] , f,protocol=2)
f.close()
print('zero data write done')
#
#f=open(datapath+'cut_features/'+dataname[data_index]+'_zerodata_2', 'wb')
#pickle.dump(zero_data[50000:], f,protocol=2)
#f.close()

#f=open(path+'cutfeatures/'+dataname[data_index]+'_zerodata_1', 'wb')
#pickle.dump([zero_data[0:100000], zero_data_label[0:100000]], f)
#f.close()
#f=open(path+'cutfeatures/'+dataname[data_index]+'_zerodata_2', 'wb')
#pickle.dump([zero_data[100000:200000], zero_data_label[100000:200000]], f)
#f.close()
#f=open(path+'cutfeatures/'+dataname[data_index]+'_zerodata_3', 'wb')
#pickle.dump([zero_data[200000:300000], zero_data_label[200000:300000]], f)
#f.close()
#
#
#





