from __future__ import division
from __future__ import print_function
import math
import numpy as np
import csv
import scipy.misc
import pickle
import pandas as pd
#from shapely.geometry import Polygon
import gc
from collections import defaultdict


datapath='/data/fzohora/dilution_series_syn_pep/'      #'/data/fzohora/water/' #'/media/anne/Study/study/PhD/bsi/update/data/water/'  #
dataname=['130124_dilA_10_01','130124_dilA_10_02', '130124_dilA_10_03', '130124_dilA_10_04', 
'130124_dilA_9_01', '130124_dilA_9_02', '130124_dilA_9_03', '130124_dilA_9_04',
'130124_dilA_11_01', '130124_dilA_11_02', '130124_dilA_11_03', '130124_dilA_11_04', 
'130124_dilA_12_01', '130124_dilA_12_02', '130124_dilA_12_03', '130124_dilA_12_04'] 
#feature_file=['130124_dilA_10_02.raw.fea.isotopes.csv', '130124_dilA_10_02.raw.fea.isotopes.csv', '130124_dilA_10_03.raw.fea.isotopes.csv', '130124_dilA_10_04.raw.fea.isotopes.csv', '130124_dilA_11_01.raw.fea.isotopes.csv', '130124_dilA_11_02.raw.fea.isotopes.csv', '130124_dilA_11_03.raw.fea.isotopes.csv', '130124_dilA_11_04.raw.fea.isotopes.csv', '130124_dilA_12_01.raw.fea.isotopes.csv', '130124_dilA_12_02.raw.fea.isotopes.csv', '130124_dilA_12_03.raw.fea.isotopes.csv',  '130124_dilA_12_04.raw.fea.isotopes.csv']#, 'Demo_LC_Chymotrypsin.raw.fea.isotopes.csv',  'Demo_LC_Trypsin.raw.fea.isotopes.csv',   'Demo_HC_AspN.raw.fea.isotopes.csv',   'Demo_HC_Chymotrypsin.raw.fea.isotopes.csv',  'Demo_HC_Trypsin.raw.fea.isotopes.csv'] 
#feature_count=[19483, 24859, 25220, 28409, 25967, 30328, 29802, 32097, 30707, 32444, 33155] #, 17776, 15919, 16350, 16220, 14312] 

RT_window=15 # 15 scans
mz_window=211 #2031
total_frames_var=20 #20 scans
RT_unit=0.01
mz_unit=0.01
mz_resolution=2


isotope_gap=np.zeros((10))
isotope_gap[0]=0.001
isotope_gap[1]=1.00
isotope_gap[2]=.50
isotope_gap[3]=.33
isotope_gap[4]=.25
isotope_gap[5]=.20
isotope_gap[6]=.17
isotope_gap[7]=.14
isotope_gap[8]=.13
isotope_gap[9]=.11


num_class=10
real_class=np.zeros((num_class))
feature_set=[]
label_set=[]
sequence_length=[]
map_to_peaks=[]

for data_index in range (4,len(dataname)):
    print(dataname[data_index])            

    f=open(datapath+'feature_list/'+dataname[data_index]+'_ms1_record', 'rb')
    RT_mz_I_dict, maxI=pickle.load(f)
    f.close()   

    print('ms1 record load done')
    f=open(datapath+'feature_list/'+dataname[data_index]+'_combineIsotopes_info', 'rb')
    total_feature,  maxI=pickle.load(f)
    f.close() 
    
    RT_list = np.sort(list(RT_mz_I_dict.keys()))
    max_RT=RT_list[len(RT_list)-1]
    min_RT=10

    
    sorted_mz_list=[]
    for i in range (0, len(RT_list)):
            #make the sorted list as well
        sorted_mz_list.append(sorted(RT_mz_I_dict[RT_list[i]]))
        

    RT_index=dict()
    for i in range(0, RT_list.shape[0]):
        RT_index[round(RT_list[i], 2)]=i    

    max_mz=0
    min_mz=1000
    for i in range(0, RT_list.shape[0]):
        mz_I_list=sorted_mz_list[i]
        mz=mz_I_list[len(mz_I_list)-1][0]
        if mz>max_mz:
            max_mz=mz
        mz=mz_I_list[0][0]
        if mz<min_mz:
            min_mz=mz

    logfile=open(datapath+'feature_list/'+dataname[data_index]+'_combineIsotopes_featureList.csv', 'rb')
    peptide_feature=np.loadtxt(logfile, delimiter=',')
    logfile.close()
    

    print('featureprep start')
    for ftr in range (0, peptide_feature.shape[0]):
#        print(ftr)
        if peptide_feature[ftr, 5]==-1: # or peptide_feature[ftr, 15]==-1:
            continue
            
        charge=int(peptide_feature[ftr, 3])
        if charge<6:
            continue

        cut_block=np.zeros((total_frames_var+RT_window-1, mz_window))
        label_block=np.zeros((total_frames_var))
        
        # m/z range
        before_10ppm=(peptide_feature[ftr, 0]*10.0)/10**6
        mz_start=round(max(peptide_feature[ftr, 0]-before_10ppm, min_mz), mz_resolution) 
        mz_end=round(mz_start+mz_window*mz_unit, mz_resolution) #ex
        
        #RT range
        poz_start=0
        if peptide_feature[ftr, 1] in RT_index:
            #found. So just start from 2 scans before and mark those 1st 2 scans as zero.
            poz_start=RT_index[peptide_feature[ftr, 1]]
        else:
            # not found, find the min index thats closer to it and > it.
            i=0
            while RT_list[i] < peptide_feature[ftr, 1]:
                i=i+1
            
            poz_start=i
            
        rt_scan_start=max(poz_start-2, 0) # seeing ONLY last two scans of (prev) adjacent feature (along RT) should not give any decision about it's existence         
        # find the ending RT of feature
        if peptide_feature[ftr, 2] in RT_index:
            poz_end=RT_index[peptide_feature[ftr, 2]]
        else:
            #select the one thats closer to it and < it ##NOT SURE if > or <
            i=0
            while RT_list[i] < peptide_feature[ftr, 2]:
                i=i+1            
            i=i-1
            poz_end=i
        
        poz_end=min(poz_end,  rt_scan_start+total_frames_var-1) # th 
        rt_scan_end=min(poz_end+RT_window-1,  len(RT_list)-1)  #th  
        # for label array, indexing start from 0
        poz_start=poz_start-rt_scan_start #th
        poz_end=poz_end-rt_scan_start #th
########################################
        y=0
        for i in range (rt_scan_start, rt_scan_end+1):
            j=0
            while(j<len(sorted_mz_list[i]) and sorted_mz_list[i][j][0]<=mz_start):
                if sorted_mz_list[i][j][0]==mz_start:
                    break
                j=j+1    
                
            temp_dict=defaultdict(list)
            while(j<len(sorted_mz_list[i]) and sorted_mz_list[i][j][0]<mz_end):
                temp_dict[sorted_mz_list[i][j][0]].append(sorted_mz_list[i][j][1])
                j=j+1
            
            temp_dict_keys=list(temp_dict.keys())
            for k in range (0, len(temp_dict)):
                temp_dict[temp_dict_keys[k]]=np.max(temp_dict[temp_dict_keys[k]])
                x=int(round((temp_dict_keys[k]-mz_start)/mz_unit, mz_resolution))
                cut_block[y, x]=temp_dict[temp_dict_keys[k]]                
            
            # fill out the mz axis
#            mz=mz_start
#            for x in range (0, cut_block.shape[1]):
#                if mz in temp_dict_keys:
#                    cut_block[y, x]=temp_dict[mz]
#                mz=round(mz+mz_unit, mz_resolution)
            y=y+1
        
        #if there is rem y, they are zero
###########################
        min_I=0
        cut_block=((cut_block-min_I)/(maxI-min_I))*255
#        bt=np.copy(cut_block)     
#        max_I=np.amax(bt)
#        min_I=0
#        bt=((bt-min_I)/(max_I-min_I))*255
#        bt=255-bt
#        scipy.misc.imsave(datapath+str(ftr)+'test.jpg', bt)        
#        
#        
########################### 
        # take the 1st one placed at starting poin
        feature_set.append(cut_block)
        label_block[0:poz_start]=0
        label_block[poz_start:poz_end+1]=charge
        label_block[poz_end+1:]=0
        label_set.append(label_block)
        sequence_length.append(poz_end+1)
        map_to_peaks.append(ftr)
        real_class[0]=real_class[0]+poz_start
        real_class[charge]=real_class[charge]+poz_end-poz_start+1

    # now feature_set has all the features + labels --> label_set
total_feature=len(feature_set)    
#    input_data=np.zeros((total_feature, RT_window*mz_window))
#    input_label=np.zeros(total_feature)    
#    for i in range (0, total_feature):
#        input_data[i, :]=feature_set[i]
#        input_label[i]=label_set[i]
#    
print(total_feature)
print(real_class)
print('writing data')    
f=open(datapath+'/cut_features/'+'z6789'+'_scanMS1_stripe_dataset', 'wb')
pickle.dump([feature_set, label_set, sequence_length, map_to_peaks, real_class], f, protocol=2)
f.close()   
print('data write done')

#    f=open(datapath+'/cut_features/'+dataname[data_index]+'_scanMS1_stripe_dataset', 'rb')
#    feature_set, label_set, sequence_length, map_to_peaks, real_class=pickle.load(f)
#    f.close()   
#4779., 21460.,     0.,     0., 13440.




